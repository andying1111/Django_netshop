#coding=utf-8
from django.conf.urls import url
from django.urls import path

from . import views
urlpatterns = [
    path(r'', views.IndexView.as_view()),
    path(r'category/(?P<cid>\d+)', views.IndexView.as_view()),
    path(r'category/(?P<cid>\d+)/page/(?P<num>\d+)', views.IndexView.as_view()),
    path(r'goodsdetails/(\d+)', views.DetailView.as_view()),

]











