#coding=utf-8
from django.conf.urls import url
from django.urls import path

from . import views

urlpatterns = [
    path(r'register/', views.RegisterView.as_view()),
    path(r'center/', views.CenterView.as_view()),
    path(r'login/', views.LoginView.as_view()),
    path(r'loadCode/', views.LoadCodeView.as_view()),
    path(r'checkCode/', views.CheckCodeView.as_view()),
    path(r'logout/', views.Logout.as_view()),
    path(r'address/', views.AddressView.as_view()),
    path(r'loadAddr/', views.loadAddr),

]